package com.exaple.mainproject;


import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class PayActivity extends Activity {
	Button btn;
	Button btn1;
	Intent in;
	Button btn2;
	Button btn3;
	Button btn4;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pay);
		btn= (Button)findViewById(R.id.cont);
		btn1= (Button)findViewById(R.id.owe);
		btn2= (Button)findViewById(R.id.owed);
		btn3= (Button)findViewById(R.id.cam);
		btn4= (Button)findViewById(R.id.qr);
btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in = new Intent(PayActivity.this, PayActivity2.class);
				
	
                startActivity(in);      
             
			}
		});
btn4.setOnClickListener(new OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent in = new Intent(PayActivity.this, PayActivity4.class);
		

        startActivity(in);      
     
	}
	
});
	
	btn1.setOnClickListener(new OnClickListener() {

		public void onClick(View v) {
			String phoneNumber;
			// TODO Auto-generated method stub
			Intent in = new Intent(Intent.ACTION_VIEW, Uri.parse("sms:"));     
			String message = null ;
			in.putExtra("sms_body", message); 
			startActivity(in);
		}
});



	btn2.setOnClickListener(new OnClickListener() {

		public void onClick(View v) {
			String phoneNumber;
			// TODO Auto-generated method stub
			Intent in = new Intent(Intent.ACTION_VIEW, Uri.parse("smsto:"));     
			String message = null ;
			in.putExtra("sms_body", message); 
			startActivity(in);
		}
});



	btn3.setOnClickListener(new OnClickListener() {
		
		public void onClick(View v) {
			// TODO Auto-generated method stub
			
			Intent in = new Intent(Intent.ACTION_PICK,
		            android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
		startActivityForResult(in,0);
			
		}
	});
	
}
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.pay, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			Intent in = new Intent(this, Activity2.class);
            this.startActivity(in);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
