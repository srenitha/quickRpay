package com.exaple.mainproject;



import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class FbActivity extends Activity {
	Button btn;
	Intent in;
	Button btn1,btn2;
	JsonParser jp= new JsonParser();
	private static String connection_url="http://196.182.0.3/android_connect/connect.php";
	private static final String Tag_success="success";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_fb);
		clickOnbutton();
	}

	private void clickOnbutton() {
		// TODO Auto-generated method stub
		btn= (Button)findViewById(R.id.fb);
		btn1= (Button)findViewById(R.id.gmail);
		btn2= (Button)findViewById(R.id.useles);
		btn.setOnClickListener(new OnClickListener() {
	

	
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent in=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.facebook.com/"));
			startActivity(in);
			btn.setTextColor(Color.RED);
			btn.setBackgroundColor(Color.YELLOW);
			
			
		}
		});
		btn2.setOnClickListener(new OnClickListener() {
			

			
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in = new Intent(FbActivity.this, Activity2.class);
				
				startActivity(in);
				btn2.setTextColor(Color.RED);
				btn2.setBackgroundColor(Color.YELLOW);
				
			}
			});
		btn1.setOnClickListener(new OnClickListener() {
	
		




	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent in=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.gmail.com/"));
		startActivity(in);
		btn1.setTextColor(Color.RED);
		btn1.setBackgroundColor(Color.YELLOW);
		
		new Connect().execute();
	}
});
	}
class Connect extends AsyncTask<String, String, String>	{
	protected String doInBackground(String...Params){
		
		String Owe = btn1.getText().toString();
		String Owed = btn2.getText().toString();
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("btn1", Owe));
		params.add(new BasicNameValuePair("btn2", Owed));
		
		JSONObject json= jp.makeHttpRequest(connection_url, "post", params);
		try
		{
			int success=json.getInt(Tag_success);
			if (success ==1)
			{
				Toast.makeText(getApplicationContext(), "Connected :)", Toast.LENGTH_LONG).show();
			}
			else
			{
				Toast.makeText(getApplicationContext(), "Not Connected :(", Toast.LENGTH_LONG).show();	
				
			}
		}catch (JSONException e){
			e.printStackTrace();
		}
		return null;
	}
}
}
