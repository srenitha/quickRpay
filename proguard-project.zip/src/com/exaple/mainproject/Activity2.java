package com.exaple.mainproject;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Activity2 extends Activity {
	Button btn,btn1,btn3,btn4,btn2;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_activity2);
		btn=(Button) findViewById(R.id.home);
		btn1=(Button) findViewById(R.id.pay);
		btn3=(Button) findViewById(R.id.rec);
		btn4=(Button) findViewById(R.id.exp);
		btn2=(Button) findViewById(R.id.inv);
		
		btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in=new Intent(Activity2.this,HomeActivity.class);
				startActivity(in);
	btn.setTextColor(Color.YELLOW);
	btn.setBackgroundColor(Color.RED);
			}
		});

		btn2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in=new Intent(Activity2.this,InviteActivity.class);
				startActivity(in);
	btn2.setTextColor(Color.YELLOW);
	btn2.setBackgroundColor(Color.RED);
			}
		});

btn4.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in=new Intent(Activity2.this,ExpActivity.class);
				startActivity(in);
				btn4.setTextColor(Color.RED);
				btn4.setBackgroundColor(Color.YELLOW);
				
			}
		});
btn3.setOnClickListener(new OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent in=new Intent(Activity2.this,RecActivity.class);
		startActivity(in);
		btn3.setTextColor(Color.RED);
		btn3.setBackgroundColor(Color.YELLOW);
	}
});

		
	
	btn1.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent in=new Intent(Activity2.this,PayActivity.class);
			startActivity(in);
			btn1.setTextColor(Color.YELLOW);
			btn1.setBackgroundColor(Color.RED);
		}
	});
}
	


}
