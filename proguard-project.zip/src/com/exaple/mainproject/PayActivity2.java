package com.exaple.mainproject;


import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.gsm.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class PayActivity2 extends Activity {
	 Button btn;
	 Button btn1;
	 Button btn2;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pay_activity2);
		btn=(Button) findViewById(R.id.online);
		btn1=(Button) findViewById(R.id.not);
		btn2=(Button) findViewById(R.id.spot);
btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
			Intent in = new Intent(PayActivity2.this, PayActivity3.class);
				 in=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.onlinesbi.com/"));
	
                startActivity(in);      
                finish();
			}
});

	
btn1.setOnClickListener(new OnClickListener() {
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		SmsManager smsManager=SmsManager.getDefault();
		smsManager.sendTextMessage("phoneNo", null, "please check your account balance", null, null);
		
	
	
	}

		
	
});
	
	btn2.setOnClickListener(new OnClickListener() {
		public void onClick(View v) {
			// TODO Auto-generated method stub
			SmsManager smsManager=SmsManager.getDefault();
			smsManager.sendTextMessage("phoneNo", null, "your payment is completed", null, null);
			
		
			
		
		
		}

			
		
	});
		}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.pay, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			Intent in = new Intent(this, Activity2.class);
            this.startActivity(in);
			return true;
		}
		return super.onOptionsItemSelected(item);
}
}
	

	




	
	